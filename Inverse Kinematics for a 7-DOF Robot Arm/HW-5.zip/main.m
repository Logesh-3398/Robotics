clc;
clear all;
close all;


%Desired pose 
Td = [0.525 0.4360 0.8984 0.7458; -0.9111 0.3893 -0.1357 -0.2994; -0.4089 -0.8119 0.4177 0.4810; 0 0 0 1];
pd  = [Td(1:3,4)];

r23 = Td(2,3);
r13 = Td(1,3);
r33 = Td(3,3);
r32 = Td(3,2);
r31 = Td(3,1);
 
phi = atan2(r23,r13);
theta = atan2(sqrt(r13^2+r23^2),r33);
psi = atan2(r32,-r31);
phid = [phi; theta; psi];
pose = [pd;phid];

steps = 10000;

%DH parameters
alpha = [pi/2, -pi/2, -pi/2, pi/2, pi/2, -pi/2, 0];
a = zeros(1,7);
d = [0.3105, 0, 0.4 , 0, 0.39, 0, 0.083];
q = zeros(7, steps);


J = zeros(6,7);
To = [0 -sin(phi) cos(phi)*sin(theta); 0 cos(phi) sin(phi)*sin(theta); 1 0 cos(theta)];

Ta = [eye(3) zeros(3); zeros(3) To];

q1 = pi/7;
q2 = pi/6;
q3 = pi/5;
q4 = pi/4; 
q5 = pi/3;
q6 = pi/2;
q7 = pi;

q(:,1) = [q1 q2 q3 q4 q5 q6 q7 ]; 
K = 10*eye(6,6);



e = zeros(6,steps);

%Loop for 
for i = 1:steps
    xe = fkine(q(:,i));
    Ja = Jg(q(:,i), pd, Ta);
    e(:,i) = pose - xe;
    qdot = pinv(Ja)*K*e(:,i);
    q(:,i+1) = q(:,i) + qdot*0.001;
    if (max(abs(e(:,i))) < 0.00001)
        q_fin = q(:,i); 
        break;
    end
end

disp("Final Pose test for ")
test = fkine(q_fin);
display(test);

disp("Desired Transformation Matrix");
disp(Td);


disp("Computed Configuration");
disp(q(:,i));

disp("Actual Transformation matrix");
disp(hmTo7(q_fin));



%Function for Forward kinematics
function  tf = fkine(q)
    
 T07 = hmTo7(q);
  
r13 = T07(1,3);
r23 = T07(2,3);
r31 = T07(3,1);
r32 = T07(3,2);
r33 = T07(3,3);
    
phi = atan2(r23,r13);
theta = atan2(sqrt(r13^2+r23^2),r33);
psi = atan2(r32,-r31);

    tf = [T07(1,4); T07(2,4); T07(3,4); phi; theta; psi];
end

function f = hmTo7(q)

%Extracting the angles from q    
    q1 = q(1); 
    q2 = q(2);
    q3 = q(3); 
    q4 = q(4); 
    q5 = q(5); 
    q6 = q(6); 
    q7 = q(7);

    A01 = [cos(q1) 0 sin(q1) 0; sin(q1) 0 -cos(q1) 0; 0 1 0 0.3105; 0 0 0 1];
    
    A12 = [cos(q2) 0 -sin(q2) 0; sin(q2) 0 cos(q2) 0; 0 -1 0 0; 0 0 0 1];
    
    A23 = [cos(q3) 0 -sin(q3) 0; sin(q3) 0 cos(q3) 0; 0 -1 0 0.4; 0 0 0 1];
        
    A34 = [cos(q4) 0 sin(q4) 0; sin(q4) 0 -cos(q4) 0; 0 1 0 0; 0 0 0 1];
        
    A45 = [cos(q5) 0 sin(q5) 0; sin(q5) 0 -cos(q5) 0; 0 1 0 0.39; 0 0 0 1];
       
    A56 = [cos(q6) 0 -sin(q6) 0; sin(q6) 0 cos(q6) 0; 0 -1 0 0; 0 0 0 1];
       
    A67 = [cos(q7) -sin(q7) 0 0; sin(q7) cos(q7) 0 0; 0 0 1 0.083; 0 0 0 1];
    
    T07 = A01*A12*A23*A34*A45*A56*A67;
    
    f = T07;
end

function Ja = Jg(q, pe, Ta)

    % extracting each angle from q(:,i)
    q1 = q(1); q2 = q(2); q3 = q(3); q4 = q(4); q5 = q(5); q6 = q(6);
    
    A01 = [cos(q1) 0 sin(q1) 0; sin(q1) 0 -cos(q1) 0; 0 1 0 0.3105; 0 0 0 1];
    A12 = [cos(q2) 0 -sin(q2) 0; sin(q2) 0 cos(q2) 0; 0 -1 0 0; 0 0 0 1];
    T02 = A01*A12;
    
    A23 = [cos(q3) 0 -sin(q3) 0; sin(q3) 0 cos(q3) 0; 0 -1 0 0.4; 0 0 0 1];
    T03 = T02*A23;
    
    A34 = [cos(q4) 0 sin(q4) 0; sin(q4) 0 -cos(q4) 0; 0 1 0 0; 0 0 0 1];
    A04 = T03*A34;
    
    A45 = [cos(q5) 0 sin(q5) 0; sin(q5) 0 -cos(q5) 0; 0 1 0 0.39; 0 0 0 1];
    T05 = A04*A45;
    
    A56 = [cos(q6) 0 -sin(q6) 0; sin(q6) 0 cos(q6) 0; 0 -1 0 0; 0 0 0 1];
    T06 = T05*A56;
    
    z0 = [0; 0; 1]; 
    p0 = [0; 0; 0];
    
    z1 = A01(1:3,3); 
    p1 = A01(1:3,4);
    
    z2 = T02(1:3,3);
    p2 = T02(1:3,4);
    
    z3 = T03(1:3,3); 
    p3 = T03(1:3,4);
    
    z4 = A04(1:3,3); 
    p4 = A04(1:3,4);
    
    z5 = T05(1:3,3); 
    p5 = T05(1:3,4);
    
    z6 = T06(1:3,3); 
    p6 = T06(1:3,4);
    
 Jg = [cross(z0,pe-p0) cross(z1,pe-p1) cross(z2,pe-p2) cross(z3,pe-p3) cross(z4,pe-p4) cross(z5,pe-p5) cross(z6,pe-p6);
        z0 z1 z2 z3 z4 z5 z6];
    
    Ja = inv(Ta)*Jg;
end




