function  tf = fkine(q)
    
 T07 = hmTo7(q);
  
r13 = T07(1,3);
r23 = T07(2,3);
r31 = T07(3,1);
r32 = T07(3,2);
r33 = T07(3,3);
    
phi = atan2(r23,r13);
theta = atan2(sqrt(r13^2+r23^2),r33);
psi = atan2(r32,-r31);

    tf = [T07(1,4); T07(2,4); T07(3,4); phi; theta; psi];
end
