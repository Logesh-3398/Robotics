clc;
clear all;
close all;
clearvars;
value = readmatrix('encoder.txt');

angle_0=1.8158;
angle_A=-0.4895;
angle_B=1.030;
angle_C=-1.9756;
angle_D=0.8674;
angle_E=-1.2490;
Length_OA = 4.123;
Length_AB = 4.123;
Length_BC = 2.828;
Length_CD = 10.770;
Length_DE = 6.324;
Length_EF = 1;

output = zeros(1, length(value));
position_O = [0, 0, 0];
position_A =  [-1, 4, 0];
position_B =  [0, 8, 0];
position_C =  [-2, 10, 0];
position_D = [8, 14, 0];
position_E = [10, 20, 0];
position_F = [11, 20, 0];
position_G = [40, 21, 0];
position_H = [40, 19, 0];
minimum_distance = position_H(1) - position_F(1);
for i = 1:length(value)
    R0=myrotmat(angle_0+value(i,1),'z');
    T00=[R0;0,0,0];
    T00=[T00,[0;0;0;1]];
    T0A=[eye(3,3); 0 0 0];
    T0A=[T0A,[Length_OA;0;0;1]];
    position_A=T00*T0A*[0;0;0;1];

    RA=myrotmat(angle_A+value(i,2),'z');
    TAA=[RA;0,0,0];
    TAA=[TAA,[0;0;0;1]];
    TAB=[eye(3,3); 0 0 0];
    TAB=[TAB,[Length_AB;0;0;1]];
    position_B=T00*T0A*TAA*TAB*[0;0;0;1];

    RB=myrotmat(angle_B+value(i,3),'z');
    TBB=[RB;0,0,0];
    TBB=[TBB,[0;0;0;1]];
    TBC=[eye(3,3); 0 0 0];
    TBC=[TBC,[Length_BC;0;0;1]];
    position_C=T00*T0A*TAA*TAB*TBB*TBC*[0;0;0;1];

    RC=myrotmat(angle_C+value(i,4),'z');
    TCC=[RC;0,0,0];
    TCC=[TCC,[0;0;0;1]];
    TCD=[eye(3,3); 0 0 0];
    TCD=[TCD,[Length_CD;0;0;1]];
    position_D=T00*T0A*TAA*TAB*TBB*TBC*TCC*TCD*[0;0;0;1];

    RD=myrotmat(angle_D+value(i,5),'z');
    TDD=[RD;0,0,0];
    TDD=[TDD,[0;0;0;1]];
    TDE=[eye(3,3); 0 0 0];
    TDE=[TDE,[Length_DE;0;0;1]];
    position_E=T00*T0A*TAA*TAB*TBB*TBC*TCC*TCD*TDD*TDE*[0;0;0;1];

    RE=myrotmat(angle_E+value(i,6),'z');
    TEE=[RE;0,0,0];
    TEE=[TEE,[0;0;0;1]];
    TEF=[eye(3,3); 0 0 0];
    TEF=[TEF,[Length_EF;0;0;1]];
    position_F=T00*T0A*TAA*TAB*TBB*TBC*TCC*TCD*TDD*TDE*TEE*TEF*[0;0;0;1];    


Slope_EF=((position_F(2) - position_E(2)) / (position_F(1) - position_E(1)));
Intercept_EF=position_F(2) - (Slope_EF*position_F(1));
Y_EF = (Slope_EF*position_G(1)) + Intercept_EF;
angle_EF = atan(Slope_EF); 
if Slope_EF > 0
    if Y_EF >= 19 && Y_EF <= 21
        output(i) = 1;
    else
        new_angle_EF = angle_EF - 0.5236; 
        Lower_Slope_EF = tan(new_angle_EF); 
        Lower_Y = position_F(2) - (Lower_Slope_EF*position_F(1));
        new_Lower_Y = (Lower_Slope_EF*position_G(1)) + Lower_Y;
        
        if new_Lower_Y > 21 
            output(i) = 0;
        else
            output(i) = 1;
        end
    end    
    elseif Slope_EF < 0
        if Y_EF >= 19 && Y_EF <= 21
            output(i) = 1;
        else
            new_angle_EF = angle_EF + 0.5236; 
            Higher_Slope_EF = tan(new_angle_EF); 
            Higher_Y = position_F(2) - (Higher_Slope_EF*position_F(1));
            new_Higher_Y = (Higher_Slope_EF*position_G(1)) + Higher_Y;

            if new_Higher_Y >= 19
                output(i) = 1;
            else
                output(i) = 0;
            end
        end
    
else
    if position_F(2) >= 19 && position_F(2) <= 21
        output(i) = 1;
    else
        if Y_EF >=21
            new_angle_EF = angle_EF - 0.5236; 
            Lower_Slope_EF = tan(new_angle_EF); 
            Lower_Y = position_F(2) - (Lower_Slope_EF*position_F(1));
            new_Lower_Y = (Lower_Slope_EF*position_G(1)) + Lower_Y;
            if new_Lower_Y > 21 
                output(i) = 0;
            else
                output(i) = 1;
            end
        elseif Y_EF < 19
            new_angle_EF = angle_EF + 0.5236; 
            Higher_Slope_EF = tan(new_angle_EF); 
            Higher_Y = position_F(2) - (Higher_Slope_EF*position_F(1));
            new_Higher_Y = (Higher_Slope_EF*position_G(1)) + Higher_Y;
            
            if new_Higher_Y >= 19
                output(i) = 1;
            else
                output(i) = 0;
            end
        end
    end
end
minimum_deviation = position_G(1) - position_F(1);
if  minimum_deviation < minimum_distance
    minimum_distance = minimum_deviation;
end 
end
disp('minimum_distance=');
disp(minimum_distance);
time = 0.0000:8/28800:(8-(8/28800));
plot(time, output, 'b');
xlim([-0.5,8]);
ylim([-0.5,1.5]);
xlabel('Time(h)');
ylabel('Binary signal');
figure(1);
function R = myrotmat(theta, axis)
switch axis
    case {'x','X'}
        R = [1 0 0 ; 0 cos(theta) -sin(theta); 0 sin(theta) cos(theta)];
    case {'y','Y'}
        R = [cos(theta) 0 sin(theta); 0 1 0; -sin(theta) 0 cos(theta)];
    case {'z','Z'}
        R = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
    otherwise
        disp('Unknown axis. Please use x, y or z');
        R = [];
end
end
