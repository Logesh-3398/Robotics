clc;
clear all;
close all;

mm = 1/1000;
steps = 10000;
Teye = eye(4);
% DH transformation of the robot
d_1 = 340 * mm;
d_2 = 0;
d_3 = 400 * mm;
d_4 = 0;
d_5 = 400 * mm;
d_6 = 0;
d_end_effector = 126 * mm;
% D-H parametersfor the camera 
q_cam_1 = deg2rad(97.31);
q_cam_2 = deg2rad(-4.70);
q_cam_3 = deg2rad(162.57);
q_cam_4 = deg2rad(103.53);
q_cam_5 = deg2rad(-1.96);
q_cam_6 = deg2rad(-62.33);
q_cam_end = deg2rad(113.31);
% New D-H Parameters for Camera
d_cam_prime = (25 + 18.1) * mm;
a_cam_prime = 0;
q_cam_prime = -pi/2;
alpha_cam_prime = 0;
d_cam = 0;
a_cam = 66.2 * mm;
q_cam = 0;
alpha_cam = 0;
% New D-H Parameters 
d_new = [d_1 d_2 d_3 d_4 d_5 d_6 d_end_effector d_cam_prime d_cam];
q_new = [q_cam_1 q_cam_2 q_cam_3 q_cam_4 q_cam_5 q_cam_6 q_cam_end q_cam_prime q_cam];
a_new = [zeros(1,7) a_cam_prime a_cam];
alpha_new = [-pi/2 pi/2 pi/2 -pi/2 -pi/2 pi/2 0 alpha_cam_prime alpha_cam];
% Forward kinematics to Camera
[T0cam, A0cam] = forward_Kinematics(d_new, q_new, a_new, alpha_new, Teye);
% Pose aruco with respect to camera values
x_cam_aruco = -0.205780720039398;
y_cam_aruco = -0.109793029482687;
z_cam_aruco = 0.561252115509121;
roll_x = deg2rad(174.1750404305652);
pitch_y = deg2rad(-17.3967534123935);
yaw_z = deg2rad(-1.9587388578232);
% Pose with rpy and transformations to aruco marker from base
pcam2aruco = [x_cam_aruco; y_cam_aruco; z_cam_aruco];
Rcam2aruco = rpy2rot(roll_x,pitch_y,yaw_z); 
Tcam2aruco = [Rcam2aruco, pcam2aruco; 0 0 0 1];
T0aruco = T0cam * Tcam2aruco;
% Transformation from Aruco maker to centre of rectangle 
xaruco2rect = ((107.95 / 2) + 50) * mm;
yaruco2rect = -((107.95 / 2) + 50) * mm;
zaruco2rect = 0;
paruco2rect = [xaruco2rect; yaruco2rect; zaruco2rect];
Taruco2rect = [eye(3), paruco2rect; 0 0 0 1];
T0rect = T0aruco * Taruco2rect;
% Transformation from Rectangle to end effector
drecEprime = 60 * mm;
qrecEprime = -pi/2;
arecEprime = 0;
alpharecEprime = pi;
% Forward kinematics Rectangle to End effector prime
[T0Eprime, Arec2Eprime] = forward_Kinematics(drecEprime, qrecEprime, arecEprime, alpharecEprime, T0rect);
% Translation from y to the end effector
xEprimeE = 0;
yEprimeE = -(33+12.5) * mm;
zEprimeE = 0;
pEprimeE = [xEprimeE; yEprimeE; zEprimeE];
TEprimeE = [eye(3), pEprimeE; 0 0 0 1];
T0e = T0Eprime * TEprimeE;
disp('Desired Transformation matrix from base to end effector is')
disp(T0e)
% Finding the pose 
d_pose = posefinder(T0e);
phi= d_pose(4,1);
theta = d_pose(5,1);
psi = d_pose(6,1);
% Ta matrix relating Geometric Jacobian to Analytic Jacobian
To = [0    -sin(phi)   cos(phi)*sin(theta); 
      0     cos(phi)   sin(phi)*sin(theta); 
      1            0            cos(theta)]; 
Ta = [eye(3) zeros(3); zeros(3) To];
% inverse Kinematics
alpha = [-pi/2, pi/2, pi/2, -pi/2, -pi/2, pi/2, 0]; 
a = zeros(1,7);
d = [d_1 d_2 d_3 d_4 d_5 d_6 d_end_effector];
q = zeros(7, steps); 
% Initial configuration
q1 = deg2rad(58.2686);
q2 = deg2rad(75.3224);
q3 = deg2rad(11.7968);
q4 = deg2rad(45.9029); 
q5 = deg2rad(-22.1081);
q6 = deg2rad(-31.2831);
q7 = deg2rad(-42.3712);
q(:,1) = [q1 q2 q3 q4 q5 q6 q7];
K = 12*eye(6,6);
e = zeros(6,steps);
for i = 1:steps 
    [T02e, A02e] = forward_Kinematics(d, transpose(q(:,i)), a, alpha, Teye); 
    xe = posefinder(T02e);
    e(:,i) = d_pose - xe;
    Ja = geo2ana(A02e,Ta);
    qdot = pinv(Ja)*K*e(:,i);
    if  q(1,i)>= deg2rad(-170) && q(1,i) <= deg2rad(170) 
        q(1,i+1) = q(1,i) + qdot(1,1)*0.01; 
    else
        q(1,i+1) = deg2rad(-170);
    end
    if  q(2,i)>= deg2rad(-120) && q(2,i) <= deg2rad(120)
        q(2,i+1) = q(2,i) + qdot(2,1)*0.01; 
    else
        q(2,i+1) = deg2rad(-120);
    end
    if  q(3,i)>= deg2rad(-170) && q(3,i) <= deg2rad(170)
        q(3,i+1) = q(3,i) + qdot(3,1)*0.01; 
    else
        q(3,i+1) = deg2rad(-170);
    end
    if  q(4,i)>= deg2rad(-120) && q(4,i) <= deg2rad(120)
        q(4,i+1) = q(4,i) + qdot(4,1)*0.01; 
    else
        q(4,i+1) = deg2rad(-120);
    end
    if  q(5,i)>= deg2rad(-170) && q(5,i) <= deg2rad(170)
        q(5,i+1) = q(5,i) + qdot(5,1)*0.01; 
    else
        q(5,i+1) = deg2rad(-170);
    end
    if  q(6,i)>= deg2rad(-120) && q(6,i) <= deg2rad(120)
        q(6,i+1) = q(6,i) + qdot(6,1)*0.01; 
    else
        q(6,i+1) = deg2rad(-120);
    end
    if  q(7,i)>= deg2rad(-175) && q(7,i) <= deg2rad(175)
        q(7,i+1) = q(7,i) + qdot(7,1)*0.01; 
    else
        q(7,i+1) = deg2rad(-175);
    end
    if (max(abs(e(:,i))) < 0.000001)
            q_final = q(:,i); 
            break;
    end
end
% Using the q_final value for further computations
q_final = q(:,i);
[T0Ea_cam, A0Ea_cam] = forward_Kinematics(d, transpose(q_final), a, alpha, Teye);
% Checking if the orientation results from the values given
q_final_deg = rad2deg(q_final);
% Initializing the values of a0,a1,a2
a0 = [q1, q2, q3, q4, q5, q6, q7];
a1 = 0;
a2 = 0;
% calculating a3,a4 and a5 
A = [10^3, 10^4, 10^5; 3*10^2, 4*10^3, 5*10^4; 6*10, 12*10^2, 20*10^3];
b1 = [q_final(1) - a0(1,1); 0; 0];
b2 = [q_final(2) - a0(1,2); 0; 0];
b3 = [q_final(3) - a0(1,3); 0; 0];
b4 = [q_final(4) - a0(1,4); 0; 0];
b5 = [q_final(5) - a0(1,5); 0; 0];
b6 = [q_final(6) - a0(1,6); 0; 0];
b7 = [q_final(7) - a0(1,7); 0; 0]; 
x = zeros(3,7);
x(:,1) = inv(A)*b1;
x(:,2) = inv(A)*b2;
x(:,3) = inv(A)*b3;
x(:,4) = inv(A)*b4;
x(:,5) = inv(A)*b5;
x(:,6) = inv(A)*b6;
x(:,7) = inv(A)*b7;
Initial_time = 0;
Final_time = 10;
t = transpose(linspace(Initial_time,Final_time,2000)); 
n = length(t);
%Maximum Velocities that joints can perform 
max_velocity = [98 98 100 130 140 180 180];
max_velocity_rad = deg2rad(max_velocity);
% Joint Trajectories
for i = 1:n
    for j = 1:7
       qgraph(j,i) = x(3,j)*t(i)^5 + x(2,j)*t(i)^4 + x(1,j)*t(i)^3 + a2*t(i)^2 + a1*t(i) + a0(j); 
       
    end
end
% Joint velocities
for i = 1:n
    for j = 1:7
        qdotgraph(j,i) = 5*x(3,j)*t(i)^4 + 4*x(2,j)*t(i)^3 + 3*x(1,j)*t(i)^2 + 2*a2*t(i) + a1; 
        if abs(qgraph(j,i)) > max_velocity_rad(j)  
         break;
       elseif i == n && abs(qgraph(j,i)) <=  max_velocity_rad(1,j)
         end
    end
end
q_values = qgraph'; 
%Exporting values to text file 
file = fopen('Gangadharan_Logesh.txt','w');
for k = 1:size(q_values)
    fprintf(file, '%6.8f %6.8f %6.8f %6.8f %6.8f %6.8f %6.8f', q_values(k,:));
    if k ~= 2000
        fprintf(file, '\n');
    end
end
fclose(file);
subplot(2,1,1);
x = t;
y1 = qgraph;
plot(x,y1)
title('Joint Trajectories')
xlabel('time-sec')
ylabel('rad')
subplot(2,1,2); 
y2 = qdotgraph;
plot(x,y2)
title('Joint Velocities')
xlabel('time-sec')
ylabel('rad/s')
% Functions used in program
function [T, T_max]  = forward_Kinematics(d, q, a, alpha, Tn)
    T = Tn;
    k = length(a);
    T_max = cell(1,k);
    for j = 1:k
        t = [cos(q(1,j)) -sin(q(1,j))*cos(alpha(1,j))  sin(q(1,j))*sin(alpha(1,j)) a(1,j)*cos(q(1,j));
             sin(q(1,j))  cos(q(1,j))*cos(alpha(1,j)) -cos(q(1,j))*sin(alpha(1,j)) a(1,j)*sin(q(1,j));
                          0                   sin(alpha(1,j))                  cos(alpha(1,j))                 d(1,j);
                          0                                  0                              0                      1];
        T = T * t;
        T_max{1,j}= T;
    end
end
function ps = posefinder(Td)
    pd  = Td(1:3,4);
    rc_23 = Td(2,3); 
    rc_13 = Td(1,3);
    rc_33 = Td(3,3);
    rc_32 = Td(3,2);
    rc_31 = Td(3,1);
 % From Rotation matrix to Euler ZYZ
    phi = atan2(rc_23,rc_13);
    theta = atan2(sqrt(rc_13^2+rc_23^2),rc_33);
    psi = atan2(rc_32,-rc_31);
    phid = [phi; theta; psi];
    ps = [pd;phid];
end 
function Rrpy = rpy2rot(roll_x,pitch_y,yaw_z) 
   roll = roll_x;
   pitch = pitch_y;
   yaw = yaw_z;
   Rrpy = eul2rotm([yaw pitch roll], 'ZYX');  
end
function Ja = geo2ana(Trans,Ta)
    z0 = [0; 0; 1]; 
    p0 = [0; 0; 0];
    pe = Trans{1,7}(1:3,3);
    z1 = Trans{1,1}(1:3,3); 
    p1 = Trans{1,1}(1:3,4);
    z2 = Trans{1,2}(1:3,3);
    p2 = Trans{1,2}(1:3,4);
    z3 = Trans{1,3}(1:3,3); 
    p3 = Trans{1,3}(1:3,4);
    z4 = Trans{1,4}(1:3,3); 
    p4 = Trans{1,4}(1:3,4);
    z5 = Trans{1,5}(1:3,3); 
    p5 = Trans{1,5}(1:3,4);
    z6 = Trans{1,6}(1:3,3); 
    p6 = Trans{1,6}(1:3,4);
    Jg = [cross(z0,pe-p0) cross(z1,pe-p1) cross(z2,pe-p2) cross(z3,pe-p3) cross(z4,pe-p4) cross(z5,pe-p5) cross(z6,pe-p6);
        z0 z1 z2 z3 z4 z5 z6];
    Ja = inv(Ta)*Jg; 
end