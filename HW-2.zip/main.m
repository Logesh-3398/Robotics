clc;
clear all;
close all;

% Define lengths of robot arm links
link1 = 0.5;  % Length of first link
link2 = 0.3;  % Length of second link
link3 = 0.2;  % Length of third link

% Define joint angle limits for each of the three joints
minTheta1 = -pi/3;
maxTheta1 = pi/3;
minTheta2 = -2*pi/3;
maxTheta2 = 2*pi/3;
minTheta3 = -pi/2;
maxTheta3 = pi/2;

% Define all corner points in the operational space using angle limits
cornerPoints = [
    minTheta1, minTheta2, minTheta3;   % All minimum
    maxTheta1, minTheta2, minTheta3;   % Max, min, min
    minTheta1, maxTheta2, minTheta3;   % Min, max, min
    minTheta1, minTheta2, maxTheta3;   % Min, min, max
    maxTheta1, maxTheta2, minTheta3;   % Max, max, min
    maxTheta1, minTheta2, maxTheta3;   % Max, min, max
    minTheta1, maxTheta2, maxTheta3;   % Min, max, max
    maxTheta1, maxTheta2, maxTheta3;   % All maximum
    minTheta1, 0,         0;           % Min, zero, zero
    maxTheta1, 0,         0;           % Max, zero, zero
    0,         maxTheta2, 0;           % Zero, max, zero
    0,         minTheta2, 0;           % Zero, min, zero
    0,         0,         minTheta3;   % Zero, zero, min
    0,         0,         maxTheta3;   % Zero, zero, max
    minTheta1, minTheta2, 0;           % Min, min, zero
    maxTheta1, minTheta2, 0;           % Max, min, zero
    minTheta1, maxTheta2, 0;           % Min, max, zero
    maxTheta1, maxTheta2, 0;           % Max, max, zero
    minTheta1, 0,         minTheta3;   % Min, zero, min
    maxTheta1, 0,         minTheta3;   % Max, zero, min
    minTheta1, 0,         maxTheta3;   % Min, zero, max
    maxTheta1, 0,         maxTheta3;   % Max, zero, max
    0,         minTheta2, minTheta3;   % Zero, min, min
    0,         maxTheta2, minTheta3;   % Zero, max, min
    0,         minTheta2, maxTheta3;   % Zero, min, max
    0,         maxTheta2, maxTheta3;   % Zero, max, max
];

% Start plotting workspace
figure();
subplot(1,2,1);
hold on;
title('Robot Workspace');

% Plot connecting arcs for configurations differing by one component
for i = 1:size(cornerPoints, 1)
    for j = 1:size(cornerPoints, 1)
        if i ~= j
            if cornerPoints(i, 1) == cornerPoints(j, 1) && cornerPoints(i, 2) == cornerPoints(j, 2)
                thetaRange = linspace(cornerPoints(j, 3), cornerPoints(i, 3), 50);
                x = link1 * cos(cornerPoints(i, 1)) + link2 * cos(cornerPoints(i, 1) + cornerPoints(i, 2)) + link3 * cos(cornerPoints(i, 1) + cornerPoints(i, 2) + thetaRange);
                y = link1 * sin(cornerPoints(i, 1)) + link2 * sin(cornerPoints(i, 1) + cornerPoints(i, 2)) + link3 * sin(cornerPoints(i, 1) + cornerPoints(i, 2) + thetaRange);
                plot(x, y, 'k');
            elseif cornerPoints(i, 1) == cornerPoints(j, 1) && cornerPoints(i, 3) == cornerPoints(j, 3)
                thetaRange = linspace(cornerPoints(j, 2), cornerPoints(i, 2), 50);
                x = link1 * cos(cornerPoints(i, 1)) + link2 * cos(cornerPoints(i, 1) + thetaRange) + link3 * cos(cornerPoints(i, 1) + thetaRange + cornerPoints(i, 3));
                y = link1 * sin(cornerPoints(i, 1)) + link2 * sin(cornerPoints(i, 1) + thetaRange) + link3 * sin(cornerPoints(i, 1) + thetaRange + cornerPoints(i, 3));
                plot(x, y, 'k');
            elseif cornerPoints(i, 2) == cornerPoints(j, 2) && cornerPoints(i, 3) == cornerPoints(j, 3)
                thetaRange = linspace(cornerPoints(j, 1), cornerPoints(i, 1), 50);
                x = link1 * cos(thetaRange) + link2 * cos(thetaRange + cornerPoints(i, 2)) + link3 * cos(thetaRange + cornerPoints(i, 2) + cornerPoints(i, 3));
                y = link1 * sin(thetaRange) + link2 * sin(thetaRange + cornerPoints(i, 2)) + link3 * sin(thetaRange + cornerPoints(i, 2) + cornerPoints(i, 3));
                plot(x, y, 'k');
            end
            o = zeros(5);
    x = linspace(0,1,5);
    y = linspace(0,1,5);
    plot(x,o,'b')
    hold on
    plot(o,y,'b')
     end
    end
      pause(0.01)
  end
axis equal;

% Detailed sweep through all joint angle possibilities for validation
theta1 = linspace(minTheta1, maxTheta1, 50);
theta2 = linspace(minTheta2, maxTheta2, 50);
theta3 = linspace(minTheta3, maxTheta3, 50);
validationX = zeros(50^3, 1);
validationY = zeros(50^3, 1);
idx = 1;

% Calculate forward kinematics for each combination of joint angles
for i = 1:length(theta1)
    for j = 1:length(theta2)
        for k = 1:length(theta3)
            x = link1 * cos(theta1(i)) + link2 * cos(theta1(i) + theta2(j)) + link3 * cos(theta1(i) + theta2(j) + theta3(k));
            y = link1 * sin(theta1(i)) + link2 * sin(theta1(i) + theta2(j)) + link3 * sin(theta1(i) + theta2(j) + theta3(k));
            validationX(idx) = x;
            validationY(idx) = y;
            idx = idx + 1;
        end
    end
end

% Plot all calculated points for validation
subplot(1,2,2);
hold on;
title('Validation plot');
plot(validationX, validationY, 'r.');
 o = zeros(5);
    x = linspace(0,1,5);
    y = linspace(0,1,5);
    plot(x,o,'b')
    plot(o,y,'b')
axis equal;


