clc;
clear all; 
close all;

% Define constants and load data
Link_1 = 0.5;
Link_2 = 0.6;
torq = load('torques.txt');
options = odeset('RelTol',1e-4,'AbsTol',[1e-5 1e-5 1e-5 1e-5]);
n = length(torq(:,1));

% Define time spans for different frequencies
Time_span_A = 1/1000;
Time_span_B = 1/200;

% Initialize matrices for storing angles
angle_A = zeros(n,2);
angle_B = zeros(n,2);

% Initial conditions for both simulations
Initial_condition_A = [0;0;0;0];
Initial_condition_B = [0;0;0;0];

% Process torque data and solve ODEs
for i = 1:n-1
    [tsimA,Output_A] = ode45(@sys,[0 Time_span_A],Initial_condition_A,options,torq(i,:)');
    angle_A(i+1,:) = Output_A(end,1:2);
    Initial_condition_A = Output_A(end,:);
    [tsimB,Output_B] = ode45(@sys,[0 Time_span_B],Initial_condition_B,options,torq(i,:)');
    angle_B(i+1,:) = Output_B(end,1:2);
    Initial_condition_B = Output_B(end,:);
end

% Calculate and plot end-effector positions
End_effector_posA = [Link_1*cos(angle_A(:,1))+Link_2*cos(angle_A(:,1)+angle_A(:,2)),Link_1*sin(angle_A(:,1))+Link_2*sin(angle_A(:,1)+angle_A(:,2))];
End_effector_posB = [Link_1*cos(angle_B(:,1))+Link_2*cos(angle_B(:,1)+angle_A(:,2)),Link_1*sin(angle_B(:,1))+Link_2*sin(angle_B(:,1)+angle_B(:,2))];
figure;
plot(End_effector_posA(:,1),End_effector_posA(:,2));
title('frequency = 1000Hz');
figure;
plot(End_effector_posB(:,1),End_effector_posB(:,2));
title('frequency = 200Hz');