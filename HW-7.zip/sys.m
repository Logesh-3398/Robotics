function x_dot = sys(t, x, torq)
    % Assign elements of x to named variables for clarity
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);
    x4 = x(4);

    % Use these variables to define q and qdot
    q = [x1; x2];
    qdot = [x3; x4];

    % Compute the dynamics matrices
    [B, C, G] = dynamics_matrices(q, qdot);

    % Calculate the accelerations
    q2dot = B \ (torq - C * qdot - G);

    % Construct the derivative of the state vector
    x_dot = [qdot; q2dot];
end
